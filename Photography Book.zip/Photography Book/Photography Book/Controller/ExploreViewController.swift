//
//  ExploreViewController.swift
//  Photography Book
//
//  Created by Hekmat on 5/4/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit
import WebKit

class ExploreViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var keywordTextField: UITextField!
    
    var ACCESS_KEY: String = "uqekjWLQ55dqbe821TtHApNgE_iKBP1onrOkaRvbuHg"
    var BASE_URL:String = "https://api.unsplash.com"
    var image: JSONResult?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    //loads image
    func loadImage(myRequest: URLRequest){
        self.webView.load(myRequest)
    }
    //refresh button was clicked
    @IBAction func refreshClicked(_ sender: Any) {
        guard var keyword = keywordTextField.text else{
            
            return
        }
        keyword = keyword.replacingOccurrences(of: " ", with: "")
        
        let myGroup = DispatchGroup()
        myGroup.enter()
        
        var myRequest:URLRequest?
        //generate random image
        generateImage(keyword: keyword) { (image) in
            //no results
            if(image.results.count == 0) {
                return
            }
            let random = Int.random(in: 0 ..< image.results.count)
            if let myURL = URL(string: (image.results[random].urls.raw)) {
                myRequest = URLRequest(url: myURL)
                myGroup.leave()
            }
        }
        myGroup.notify(queue: .main) {
            if let request = myRequest{
                self.webView.load(request)
            }
        }
        
        
    }
    
    //generate random image from API based on keyword
    func generateImage(keyword: String, onSuccess: @escaping (JSONResult) -> Void){
        if let url = URL(string: "\(BASE_URL)/search/photos?page=1&query=\(keyword)&per_page=40"){
            var urlRequest = URLRequest(url: url)
            // Set the Authorization Header with my access token
            urlRequest.setValue("Client-ID \(ACCESS_KEY)", forHTTPHeaderField: "Authorization")
            URLSession.shared.dataTask(with: urlRequest, completionHandler: {(data, response, error) in
                if let data = data{
                    // We have data!!!
                    do{
                        self.image = try JSONDecoder().decode(JSONResult.self, from: data)
                        onSuccess(self.image!)
                    } catch {
                        print("error while loading api",error)
                    }
                }
            }).resume()
        }
    }


}
