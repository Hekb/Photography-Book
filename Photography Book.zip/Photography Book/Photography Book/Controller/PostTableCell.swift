//
//  PostTableCell.swift
//  Photography Book
//
//  Created by Hekmat on 5/6/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//
// Table Cell class to hold an event detials
import UIKit

class PostTableCell: UITableViewCell {

    @IBOutlet weak var title: UILabel!
}
