//
//  RegisterViewController.swift
//  Photography Book
//
//  Created by Hekmat on 5/1/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var firstnameField: UITextField!
    @IBOutlet weak var lastnameField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var errorMessage: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        errorMessage.isHidden = true
    }
    

    //register button was clicked
    @IBAction func registerClicked(_ sender: Any) {
        guard let firstname = firstnameField.text else {
            errorMessage.text = "Missing First Name field"
            self.errorMessage.isHidden = false
            return
        }
        guard let lastname = lastnameField.text else {
            errorMessage.text = "Missing Last Name field"
            self.errorMessage.isHidden = false
            return
        }
        guard let email = emailField.text else {
            errorMessage.text = "Missing Email field"
            self.errorMessage.isHidden = false
            return
        }
        guard let password = passwordField.text else {
            errorMessage.text = "Missing Password field"
            self.errorMessage.isHidden = false
            return
        }
        if(firstname.isEmpty || lastname.isEmpty){
            errorMessage.text = "Missing Data field"
            self.errorMessage.isHidden = false
            return
        }
        
        

        
        let newUser: user = user(uid: "", email: email, password: password, fullname: firstname + " " + lastname, userName: "")
        //check if user exsits
        DatabaseManger.shared.createUser(newUser: newUser){
            error in
            if(error != "success"){
                self.errorMessage.text = error
                self.errorMessage.isHidden = false

            }else{
                //user exsits
                DatabaseManger.shared.singIn(email: email, password: password){
                    success in
                    // try to sign
                    if(success != "success"){
                        self.errorMessage.text = success
                        self.errorMessage.isHidden = false
                    }else{
                        self.navigateToHome()
                    }
                }
                
            }
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.resignFirstResponder()
    }
    
    
    //navigate to home once successfully registering
    func navigateToHome(){
        let loginVC = self.storyboard!.instantiateViewController(withIdentifier: "HomeVC") as! HomeViewController
        let navController = UINavigationController(rootViewController: loginVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }
    
}
