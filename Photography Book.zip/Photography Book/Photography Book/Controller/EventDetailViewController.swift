//
//  EventDetailViewController.swift
//  Photography Book
//
//  Created by Hekmat on 5/2/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit
import EventKit

class EventDetailViewController: UIViewController {
    
    var event: [String:String] = [:]
    @IBOutlet weak var titleField: UITextField!
    @IBOutlet weak var hostedField: UITextField!
    @IBOutlet weak var streetField: UITextField!
    @IBOutlet weak var dateField: UITextField!
    @IBOutlet weak var attendingList: UILabel!
    @IBOutlet weak var details: UITextView!
    @IBOutlet weak var attendButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleField.isUserInteractionEnabled = false
        hostedField.isUserInteractionEnabled = false
        streetField.isUserInteractionEnabled = false
        dateField.isUserInteractionEnabled = false
        
        loadEvent()
    }
    //loads events detail
    func loadEvent(){
        guard let name = event["name"] else {return}
        guard let address = event["address"] else {return}
        guard let date = event["date"] else {return}
        guard let detail = event["name"] else {return}
        
        titleField.text = name
        streetField.text = address
        //get host name based on uid
        DatabaseManger.shared.returnUserName(uid: event["host"]!){
            name in
            self.hostedField.text = name[0]
        }
        dateField.text = date
        details.text = detail
        
        if(event["host"] == DatabaseManger.shared.currentUser?.uid){
            attendButton.isEnabled = false
            attendButton.backgroundColor = .lightGray
        }else{
            attendButton.isEnabled = true
        }
        
        //get how many attending
        if let list = event["attendingList"]{
            let attendies = list.components(separatedBy: ", ")
            if(attendies.contains((DatabaseManger.shared.currentUser?.uid)!)){
                attendButton.isEnabled = false
                attendButton.backgroundColor = .lightGray
            }
            attendingList.text = String(attendies.count)
        }else{
            attendingList.text = "0"
        }

    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    //attend was clicked
    @IBAction func attendClicked(_ sender: Any) {
        guard let userID = DatabaseManger.shared.currentUser?.uid else {return}
        //it is the users uid then they cannt attend
        if(event["host"] == userID){
            return
        }
        //add the current user to the attendie list
        //if user is already aattending then don't add
        if var list = event["attendingList"]{
            let attendies = list.components(separatedBy: ",")
            print("attendise", attendies.count)
            if(list.contains(userID)){
                print("user alreadying attending")
                return
            }
            list += ", " + (userID)
            DatabaseManger.shared.updateAttendingList(newAttendingList: list, eventTitle: event["name"]!)
        }else{
            let list = userID 
            DatabaseManger.shared.updateAttendingList(newAttendingList: list, eventTitle: event["name"]!)
        }
        
    }
    
    //adds event to calender
    @IBAction func addToCalanderClicked(_ sender: Any) {
        let eventStore: EKEventStore = EKEventStore()
        eventStore.requestAccess(to: .event) { (granted, error) in
            if error != nil{
                print("error while exporting to calander")
                return
            }
            if(granted){
                //h:mm a 'on' MMMM dd, yyyy
                let event:EKEvent = EKEvent(eventStore: eventStore)
                event.title = self.event["name"]
                let formatter = DateFormatter()
                formatter.locale = Locale(identifier: "en_US_POSIX")
                formatter.dateFormat = "h:mm a 'on' MMMM dd, yyyy"
                formatter.amSymbol = "AM"
                formatter.pmSymbol = "PM"
                let date = formatter.date(from: self.event["date"]!)
                event.startDate = date
                event.endDate = date
                event.calendar = eventStore.defaultCalendarForNewEvents
                do {
                    try eventStore.save(event, span: .thisEvent)
                }catch{
                    
                }
                
            }
        }
        let alert = UIAlertController(title: "Success", message:
            "Event Added to Your Calander", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .default))
        self.present(alert, animated: true, completion: nil)
        
    }
    
}
