//
//  HomeViewController.swift
//  Photography Book
//
//  Created by Hekmat on 5/1/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit
import Firebase
import MapKit
import CoreLocation
import FirebaseAuth


class HomeViewController: UIViewController, MKMapViewDelegate{


    @IBOutlet weak var leading: NSLayoutConstraint!
    @IBOutlet weak var trailing: NSLayoutConstraint!
    
    @IBOutlet weak var slideView: UIView!
    @IBOutlet weak var mapView: MKMapView!
    
    var menuDisplayed: Bool?
    
    var e:[String: String]? = nil
    var userEvents:[event]?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        //check if user is logged in
        if(!isUserLoggedIn()){
            showLoginScreen()
        }
        //loads the current user
        DatabaseManger.shared.loadUser()
        //load data
        loadData()
        //set up delegates
        mapView.delegate = self
        menuDisplayed = false
        //load map
        loadMap()
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Map delegate
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation{
            return nil
        }
        var annotationView = self.mapView.dequeueReusableAnnotationView(withIdentifier: "Pin")
        if annotationView == nil{
            annotationView = AnnotationView(annotation: annotation, reuseIdentifier: "Pin")
            annotationView?.canShowCallout = false
        }else{
            annotationView?.annotation = annotation
        }
        annotationView?.image = UIImage(named: "mapPin")
        return annotationView
    }
    
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView){
        //location is not available
        if view.annotation is MKUserLocation{
            // Don't proceed with custom callout
            return
        }
        // create an annontation
        let annotation = view.annotation as! CustomAnnotation
        let views = Bundle.main.loadNibNamed("customAnnotation", owner: nil, options: nil)
        let calloutView = views?[0] as! CustomCalloutView
        //set annontation info
        calloutView.label2.text = annotation.host
        calloutView.label1.text = annotation.date
        calloutView.event = annotation.e
        calloutView.layer.cornerRadius = 25
        calloutView.clipsToBounds = true
        
        //calloutView.frame = CGRect(x: 0 , y: 0, width: self.view.frame.width/1.5, height: self.view.frame.height * 0.4)
        calloutView.profilePic.image = URLToImg(URL(string: annotation.profilePic))
        calloutView.profilePic?.layer.cornerRadius = (calloutView.profilePic?.frame.height ?? 40.0) / 2.0

        
        let button = UIButton(frame: calloutView.button.frame)
        button.addTarget(self, action: #selector(HomeViewController.showEventDetailClicked(sender:)), for: .touchUpInside)
        calloutView.addSubview(button)
        calloutView.center = CGPoint(x: view.bounds.size.width / 2, y: -calloutView.bounds.size.height*0.52)
        
        view.addSubview(calloutView)
        mapView.setCenter((view.annotation?.coordinate)!, animated: true)
    }
    
    //map delegate
    func mapView(_ mapView: MKMapView, didDeselect view: MKAnnotationView) {
        if view.isKind(of: AnnotationView.self){
            for subview in view.subviews{
                subview.removeFromSuperview()
            }
        }
    }
    
    
    //loads up data
    func loadData(){
        DispatchQueue.main.async {
            DatabaseManger.shared.loadData { events in
                //loads all users events
                self.userEvents = []
                let allEvents = DatabaseManger.shared.events
                guard let currentUserUID = DatabaseManger.shared.currentUser?.uid else {return}
                for event in allEvents{
                    if(event.hostedBy! == currentUserUID){
                        self.userEvents?.append(event)
                        
                    }
                }
                //loads up the markers
                for e in events{
                    _ = DatabaseManger.shared.returnUserName(uid: e.hostedBy!, onSuccess: { (result) in
                        let point = CustomAnnotation(host: result[0], date: e.date!
                            , profilePic: result[1], coordinate: CLLocationCoordinate2D(latitude: e.lat!, longitude: e.long!), ev: e)
                        self.mapView.addAnnotation(point)
                    })

                    
                }
            }
        }
    }
    
    //reload page was clicked
    @IBAction func reloadClicked(_ sender: Any) {
        let allAnnotations = self.mapView.annotations
        self.mapView.removeAnnotations(allAnnotations)
        loadData()
    }
    
    //loads maps location
    func loadMap(){
        let initialLocation = CLLocation(latitude: 34.0271383, longitude: -118.2731531)
        mapView.centerToLocation(initialLocation)
    }
    
    
    //adds marker to map
    func addMarkerAnnotation(marker: CustomAnnotation){
        mapView.addAnnotation(marker)
    }
     
    
    //prepare function for segues
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("loading segue")
        if(segue.identifier == "HomeToDetail"){
            if let nextVC = segue.destination as? EventDetailViewController{
                guard let event = self.e else {return}
                nextVC.event = event
                print("done loading segue")
            }
        }else if(segue.identifier == "profileSeg"){
            if let nextVC = segue.destination as? ProfileViewController{
                nextVC.usersEvents = userEvents
                print("done loading segue to profile")
            }
        }
    }

    //side menu tapped
    @IBAction func menuTapped(_ sender: Any) {
        if(menuDisplayed!){
            leading.constant = 0
            trailing.constant = 0
            menuDisplayed = false
        }else{
            leading.constant = 150
            trailing.constant = -150
            menuDisplayed = true
        }
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseIn, animations: {
            self.view.layoutIfNeeded()
        }, completion: { (error) in
            
        })
    }
    
    //shows to login page
    func showLoginScreen() {
        let loginVC = self.storyboard!.instantiateViewController(withIdentifier: "LoginView") as! LoginViewController
        let navController = UINavigationController(rootViewController: loginVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }
    
    //checks if user is logged in
    func isUserLoggedIn() -> Bool{
        if Auth.auth().currentUser == nil{
            print("no user is logged in")
            return false
        }else{
            print("user is logged in")
            return true
        }
    }
    
    //log out was clicked
    @IBAction func logoutClicked(_ sender: Any) {
        do{
            try Auth.auth().signOut()
            print("user logged out")
            showLoginScreen()
        }catch{
            print("error while loggin out")
        }
    }
    
    //Event show details was clicked
    @objc func showEventDetailClicked(sender: UIButton){
        let v = sender.superview as! CustomCalloutView
        guard let ev = v.event else {return}
        //retrive event into and then go event detail page
        DatabaseManger.shared.retriveEvent(eventTitle: ev.title!){result in
            self.e = result
            self.performSegue(withIdentifier: "HomeToDetail", sender: nil)
        }
    }

    
    // Converts a URL to an image
    func URLToImg(_ url: URL?) -> UIImage?{
        guard let imageURL = url else{
            return nil
        }
        let data = try? Data(contentsOf: imageURL)
        return UIImage(data: data!)
    }
}
private extension MKMapView {
  func centerToLocation(_ location: CLLocation,regionRadius: CLLocationDistance = 1000) {
    let coordinateRegion = MKCoordinateRegion(
      center: location.coordinate,
      latitudinalMeters: regionRadius,
      longitudinalMeters: regionRadius)
    setRegion(coordinateRegion, animated: true)
  }
     
}
