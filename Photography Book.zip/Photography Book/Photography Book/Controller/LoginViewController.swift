//
//  LoginViewController.swift
//  Photography Book
//
//  Created by Hekmat on 5/1/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit
import FirebaseAuth
import GoogleSignIn
import Firebase
class LoginViewController: UIViewController, GIDSignInDelegate {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var errorMessage: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        errorMessage.isHidden = true
        
        //set up delegates
        GIDSignIn.sharedInstance().clientID = FirebaseApp.app()?.options.clientID
        GIDSignIn.sharedInstance().delegate = self
        
    }

    //if login was clickeds
    @IBAction func loginClicked(_ sender: Any) {
        guard let email = emailField.text else{
            self.errorMessage.text = "Missing Data Fields"
            self.errorMessage.isHidden = false
            return
        }
        guard let pass = passwordField.text else {
            self.errorMessage.text = "Missing Data Fields"
            self.errorMessage.isHidden = false
            return
        }
        if(pass.isEmpty || email.isEmpty){
            self.errorMessage.text = "Missing Data Fields"
            self.errorMessage.isHidden = false
            return
        }
        //try to sign in
        DatabaseManger.shared.singIn(email: email, password: pass){
            error in
            //error while logging in
            if(error != "success"){
                //successful sign in
                self.errorMessage.text = error
                self.errorMessage.isHidden = false
            }else{
                //no error while loggin in
                self.navigateToHome()
            }
        }
        

    }
    
    //sign in with google button was clicked
    @IBAction func signInWithGoogleClicked(_ sender: Any) {
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.signIn()
    }
    
    //function to sign in with google
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if error != nil {
           print("error happened! while logging in")
           return
         }

         guard let authentication = user.authentication else { return }
         let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                           accessToken: authentication.accessToken)
        //call data base function to add the new user identity (if new)
        DatabaseManger.shared.GoogleSign(credientials: credential){
                result in
            self.navigateToHome()
        }
    }
    //functio to navigate to hom
    func navigateToHome(){
        let loginVC = self.storyboard!.instantiateViewController(withIdentifier: "HomeVC") as! HomeViewController
        let navController = UINavigationController(rootViewController: loginVC)
        navController.modalPresentationStyle = .fullScreen
        self.present(navController, animated:true, completion: nil)
    }


}
