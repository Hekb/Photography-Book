//
//  ProfileViewController.swift
//  Photography Book
//
//  Created by Hekmat on 5/2/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var locationLabel: UILabel!
    
    var usersEvents: [event]?
    var isComplete = false
    var RowSelected = 0
    var event:[String: String]?
    override func viewDidLoad() {
        super.viewDidLoad()
        loadUserInfo()
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    // Sets the height of each table cell
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    //table delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersEvents!.count
    }

    
    // Sets the content within each table row cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let userRow = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! PostTableCell

        userRow.title?.text = usersEvents![indexPath.row].title! + " at " + usersEvents![indexPath.row].date!
        
        return userRow
    }
    //table delegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        RowSelected = indexPath.row
        isComplete = true
        DatabaseManger.shared.retriveEvent(eventTitle: usersEvents![RowSelected].title!){result in
            self.event = result
            self.performSegue(withIdentifier: "cellToDetails", sender: self)
        }
    }
    
    //prepare function
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "cellToDetails") {
            isComplete = false
            //load event obj into event detial VC
            if let nextViewController = segue.destination as? EventDetailViewController {
                nextViewController.event = self.event!
            }
        }
    }
    //check if we're rready to perform segue
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if (identifier == "cellToDetails") {
            return isComplete
        }
        return true
    }
    //loads users info and image
    func loadUserInfo(){
        let loggedUser = DatabaseManger.shared.currentUser
        guard let name = loggedUser?.fullname else {
            return
        }
        guard let loc = loggedUser?.currentLocation else{
            return
        }
        guard let profileImage = loggedUser?.profileImage else{
            return
        }

        self.title = name + " Profile"
        self.profileImage.image = URLToImg(URL(string: profileImage))
        self.locationLabel.text = "Location: " + loc
        let width:CGFloat = UIScreen.main.bounds.width*0.555
        self.profileImage.frame = CGRect(x: 0,y: 0,width: width,height: width)
        self.profileImage.layer.masksToBounds = true
        self.profileImage.layer.cornerRadius = width/2
        self.profileImage.isUserInteractionEnabled = true
        self.profileImage.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleImageClick)))
        

    }
    
    //handles loading images into profile UIView
    @objc func handleImageClick() {
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true, completion: nil)
    }
    
    //ImagePickerController for loading the image
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        var newProfileImage: UIImage?
        print("Image Upload Clicked")
        if let editedImage = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")] as? UIImage{
            newProfileImage = editedImage
        }else if let original = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerOriginalImage")] as? UIImage{
            newProfileImage = original
        }
        if let newImage = newProfileImage{
            profileImage.image = newImage
        }
        DatabaseManger.shared.uploadImage(image: profileImage)
        dismiss(animated: true, completion: nil)
    }
    
    //if we exit picker
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    // Converts a URL to an image
    func URLToImg(_ url: URL?) -> UIImage?{
        guard let imageURL = url else{
            return nil
        }
        let data = try? Data(contentsOf: imageURL)
        return UIImage(data: data!)
    }
}
