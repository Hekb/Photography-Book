//
//  CustomCalloutView.swift
//  Photography Book
//
//  Created by Hekmat on 5/4/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit

class CustomCalloutView: UIView {
    
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var profilePic: UIImageView!
    var event:event?
}
