//
//  CreateEventViewController.swift
//  Photography Book
//
//  Created by Hekmat on 5/2/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import UIKit
import MapKit

class CreateEventViewController: UIViewController {

    @IBOutlet weak var eventTitle: UITextField!
    @IBOutlet weak var street: UITextField!
    @IBOutlet weak var state: UITextField!
    @IBOutlet weak var zipcode: UITextField!
    @IBOutlet weak var details: UITextView!
    @IBOutlet weak var date: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func addEventClicked(_ sender: Any) {
        guard let title = eventTitle.text else {
            return
        }
        guard let street = street.text else{
            return
        }
        guard let state = state.text else{
            return
        }
        guard let zipcode = zipcode.text else{
            return
        }
        guard let details = details.text else{
            return
        }
        //checks if any fields are empty
        if(title.isEmpty || street.isEmpty || state.isEmpty
            || zipcode.isEmpty || details.isEmpty){
            let alert = UIAlertController(title: "Missing Data Fields", message:
                "Please Enter Values For All of the Fields", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        //converts date to a date format
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "h:mm a 'on' MMMM dd, yyyy"
        formatter.amSymbol = "AM"
        formatter.pmSymbol = "PM"
        let dateString = formatter.string(from: date.date)

        print(dateString)

        //create a new marker
        _ = getCoordinates(address: street + "," + state + " " + zipcode){
            result in
            if(result.count == 0){
                //displays an error if something goes wrong
                let alert = UIAlertController(title: "Wrong Address", message:
                    "Please Enter a Right Address", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Dismiss", style: .default))
                self.present(alert, animated: true, completion: nil)
            }else{
                let hostID = DatabaseManger.shared.currentUser?.uid
                DatabaseManger.shared.addEvent(address: street + "," + state, date: dateString, details: details, host: hostID!, name: title, time: dateString, zipcode: zipcode, attendingList: "")
                let e = event(title: title, lat: result[0], long: result[1], date: dateString, time: dateString, attendingList:"", details: details, hostedBy: hostID!)
                
                _ = DatabaseManger.shared.returnUserName(uid: hostID!, onSuccess: { (result1) in
                    let point = CustomAnnotation(host: result1[0], date: dateString
                        , profilePic: result1[1], coordinate: CLLocationCoordinate2D(latitude: result[0], longitude: result[1]), ev: e)
                    let homeVC = self.navigationController!.viewControllers[0] as! HomeViewController
                    homeVC.addMarkerAnnotation(marker: point)
                    self.navigationController!.popToRootViewController(animated: true)

                })
                //let point = CustomAnnotation(host: result[0], date: e.date!
                //, profilePic: result[1], coordinate: CLLocationCoordinate2D(latitude: e.lat!, longitude: e.long!), ev: e)
            }
        }
        

    }
    //gets lat and long of an address
    public func getCoordinates(address:String, onSuccess: @escaping ([Double]) -> Void) {
        let geocoder = CLGeocoder()
        var lat: Double?
        var long: Double?
        var coordinates: [Double] = []

        geocoder.geocodeAddressString(address) { (placemarks, error) in
            if(error != nil){
                //something wrong happened
                onSuccess(coordinates)
            }
            if let placemark = placemarks?[0] {
                let location = placemark.location!
                lat = location.coordinate.latitude
                long = location.coordinate.longitude
                coordinates.append(lat!)
                coordinates.append(long!)
                onSuccess(coordinates)
            }
        }

    }

}
