//
//  user.swift
//  Photography Book
//
//  Created by Hekmat on 5/1/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import Foundation

public class user{
    var email: String?
    var fullname: String?
    var pass:String?
    var userName: String?
    var profileImage: String?
    var currentLocation: String?
    var uid: String?
    
    
    
    //init to set up a user obj
    init(uid: String, email: String, password: String, fullname: String, userName: String){
        self.uid = uid
        self.email = email
        self.pass = password
        self.fullname = fullname
        self.userName = userName
        self.profileImage = "https://lh5.googleusercontent.com/-0NnpKH7ZNQg/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3reDvaXRqoVULPzOmfORSpH4_EQEeg/s96-c/photo.jpg"
        self.currentLocation = "Los Angeles"
        
    }
    //init to set up a user obj
    init(uid: String, email: String, password: String, fullname: String, userName: String,
         location: String, profileImage: String){
        self.uid = uid
        self.email = email
        self.pass = password
        self.fullname = fullname
        self.userName = userName
        self.profileImage = profileImage
        self.currentLocation = location
        
    }

    
    
    
}
