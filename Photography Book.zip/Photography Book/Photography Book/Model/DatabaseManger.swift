//
//  DatabaseManger.swift
//  Photography Book
//
//  Created by Hekmat on 5/1/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//  The purpose of this class is to contain all of the database
//  functions in one package

import Foundation
import Firebase
import FirebaseFirestore
import MapKit
import FirebaseCore
import FirebaseAuth
import FirebaseStorage
import GoogleSignIn


class DatabaseManger{
    //varaibeles
    static var shared = DatabaseManger()
    var currentUser:user?
    //events array
    var events: [event] = []
    let db = Firestore.firestore()

        
    init(){
        currentUser = nil
    }
    //load user info
    func loadUser(){
        let currEmail = Auth.auth().currentUser?.email
        db.collection("users").getDocuments { (querySnapshot, err) in
            if let err = err{
                print("error while loading up the current user", err.localizedDescription)
                return
            }
            for document in querySnapshot!.documents{
                let email = document.get("email") as! String
                // we have found the current user info
                if(email == currEmail){
                    let fullname = document.get("fullname") as! String
                    let username = document.get("username") as! String
                    let profileImage = document.get("profileImage") as! String
                    let location = document.get("location") as! String
                    let uid = document.get("uid") as! String
                    let u = user(uid: uid, email: email, password: "", fullname: fullname, userName: username, location: location, profileImage: profileImage)
                    self.currentUser = u
                    return
                }
            }
        }
    }
    //load events
    func loadData(onSuccess: @escaping ([event]) -> Void){
        let myGroup = DispatchGroup()
        self.events.removeAll()
        db.collection("events").getDocuments() { (querySnapshot, err) in
            print(1)
            if let err = err {
                print("Error getting documents: \(err)")
            }
            for document in querySnapshot!.documents {
            
                myGroup.enter()
                let address = document.get("address") as! String
                let date = document.get("date") as! String
                let details = document.get("details") as! String
                let host = document.get("host") as! String
                let name = document.get("name") as! String
                let time = document.get("time") as! String
                let zipcode = document.get("zipcode") as! String
                let attendingList = document.get("attendingList") as! String
                self.generateLatLong(address: address + " " + zipcode, onSuccess: { (coor) in
                    let e = event(title: name, lat: coor[0], long: coor[1], date: date, time: time,
                        attendingList:attendingList, details: details, hostedBy: host)
                    self.events.append(e)
                    myGroup.leave()
                })
            }
            myGroup.notify(queue: .main) {
                onSuccess(self.events)
            }

            
        }
    }
    //generate lat and long
    func generateLatLong(address:String, onSuccess: @escaping ([Double]) -> Void){
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(address) { (placemarks, error) in
            if let placemark = placemarks?[0] {
                let location = placemark.location!
                onSuccess([location.coordinate.latitude, location.coordinate.longitude])
            }
        }
    }

    
    //function that creates a new user
    func createUser(newUser: user, onSuccess: @escaping (String) -> Void){
        guard let email = newUser.email else {return}
        guard let password = newUser.pass else {return}
        guard let fullname = newUser.fullname else {return}
        guard let username = newUser.userName else {return}
        
        Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
            
            //If an error occurs
            if let er = error{
                print("Error occured while siging up: \(er.localizedDescription)")
                onSuccess(er.localizedDescription)
                return
            }
            guard let userUID = result?.user.uid else{return}
            let data = ["email": email, "fullname": fullname, "username": username, "uid": userUID, "profileImage": "https://lh5.googleusercontent.com/-0NnpKH7ZNQg/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3reDvaXRqoVULPzOmfORSpH4_EQEeg/s96-c/photo.jpg", "location": "los angeles"]
            self.db.collection("users").addDocument(data: data) { (error) in
                if error != nil {
                    print("error occured while inserting document")
                }
                print("New user addded")
                onSuccess("success")
            }
        
        }
        
    }
    
    // adds a new user to DB if it does not exists
    func addUserToDB(newUser: user){
        guard let email = newUser.email else {return}
        guard newUser.pass != nil else {return}
        guard let fullname = newUser.fullname else {return}
        guard let username = newUser.userName else {return}
        guard let userUID = newUser.uid else{return}
        let data = ["email": email, "fullname": fullname, "username": username, "uid": userUID, "profileImage": "https://lh5.googleusercontent.com/-0NnpKH7ZNQg/AAAAAAAAAAI/AAAAAAAAAAA/ACHi3reDvaXRqoVULPzOmfORSpH4_EQEeg/s96-c/photo.jpg", "location": "los angeles"]
        self.db.collection("users").addDocument(data: data) { (error) in
            if error != nil {
                print("error occured while inserting document")
                return
            }
            print("New user addded")
        }
    }
    //function that addes an event to the database
    func addEvent(address: String, date: String, details: String, host: String,
                  name:String, time:String, zipcode: String, attendingList:String){
        let data = ["address": address, "date": date, "details": details, "host": host, "name":name,
                    "time": time, "zipcode":zipcode, "attendingList": attendingList]
        self.db.collection("events").addDocument(data: data) { (error) in
            if error != nil {
                print("error occured while inserting document")
            }
            print("new event added")
        }
    }
    //returns name assosiated with a UID
    func returnUserName(uid:String, onSuccess: @escaping ([String]) -> Void){
        db.collection("users").getDocuments { (querySnapshot, err) in
            if let err = err{
                print("error while loading up the current user", err.localizedDescription)
                return
            }
            for document in querySnapshot!.documents{
                let userUID = document.get("uid") as! String
                if(userUID == uid){
                    let name = document.get("fullname") as! String
                    let profilePic = document.get("profileImage") as! String
                    onSuccess([name, profilePic])
                }
            }
        }
    }
    
    //function to sign in a user
    func singIn(email: String, password: String, onSuccess: @escaping (String) -> Void){

        Auth.auth().signIn(withEmail: email, password: password) { (result, error) in
            
            if let er = error{
                print("Error while loggin: \(er.localizedDescription)")
                onSuccess(er.localizedDescription)
                return
            }
            print("Logged in Successfully")
            onSuccess("success")
        }
        
    }
    
    //Google sing in method
    func GoogleSign (credientials: AuthCredential, onSuccess: @escaping (String) -> Void){
        Auth.auth().signIn(with: credientials) { (result, error) in
            if let error = error{
                print("error while google sign in", error)
                return
            }
            guard let uid = result?.user.uid else{return}
            guard let email = result?.user.email else{return}
            guard let name = result?.user.displayName else{return}
            
            //create new user
            let newUser: user = user(uid: uid as String, email: email, password: "", fullname: name, userName: "")
            //check if user exsits in db first
            self.checkIfUserExsits(uid: uid, newUser: newUser)
            onSuccess("")
        }
    }
    //check if user exsits
    func checkIfUserExsits(uid: String, newUser: user){
        let docRef = db.collection("users").whereField("uid", isEqualTo: uid).limit(to: 1)

        docRef.getDocuments { (querysnapshot, error)  in
            if error != nil {
                self.addUserToDB(newUser: newUser)
                return
            } else {
                if let doc = querysnapshot?.documents, !doc.isEmpty {
                    return
                }
            }
        }
        self.addUserToDB(newUser: newUser)
        
    }
    //sign out
    func signOut(){
        do{
            try Auth.auth().signOut()
            self.currentUser = nil
        }catch let error {
            print("error while sign out: \(error.localizedDescription)")
        }
    }
    
    //checks if user is authenticated/loggedin
    func isUserLogedIn() -> Bool{
        if Auth.auth().currentUser == nil{
            print("no user is logged in")
            return false
        }else{
            print("user is logged in")
            return true
        }
    }
    

    //retrive events info based on the title
    func retriveEvent(eventTitle: String, onSuccess: @escaping ([String: String]) -> Void){
        var _: [String: String] = [:]
        db.collection("events").getDocuments() { (querySnapshot, err) in
            if let err = err {
                print("Error getting documents: \(err)")
            } else {
                for document in querySnapshot!.documents {
                    let title = document.get("name") as! String
                    print("comparing:", eventTitle, "and", title)
                    if(eventTitle == title){
                        let address = document.get("address") as! String
                        let date = document.get("date") as! String
                        let host = document.get("host") as! String
                        let details = document.get("details") as! String
                        let zipcode = document.get("zipcode") as! String
                        let time = document.get("time") as! String
                        let attendingList = document.get("attendingList") as! String
                        print("attending:", attendingList)
                        let data = ["address": address + " " + zipcode, "date": date, "details": details, "host": host, "name":title,
                                    "time": time, "zipcode":zipcode, "attendingList": attendingList]
                        onSuccess(data)
                    }
                }
            }
        }
    }
    
    //uploads an image to firebase storage and generate a link
    public func uploadImage (image: UIImageView){
        var uploadedImageURL: String?
        if let data = image.image!.pngData(){
                let imageName = NSUUID().uuidString
                // Create a reference to the file you want to upload
                let imageRef = Storage.storage().reference().child(imageName)
                // Upload the file to the path
                _ = imageRef.putData(data, metadata: nil) { (metadata, error) in
                  guard let metadata = metadata else {
                    return
                  }
                  // Metadata contains file metadata such as size, content-type.
                _ = metadata.size
                  imageRef.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                      // Uh-oh, an error occurred!
                      return
                    }
                    print("Image link: \(downloadURL)")
                    uploadedImageURL = downloadURL.absoluteString
                    self.currentUser?.profileImage = uploadedImageURL
                    //update the profile info with the new link
                    self.updateProfileImage(profileURL: uploadedImageURL ?? "")
                  }
            }
        }
    }
    
    //updates profile image of the user
    public func updateProfileImage(profileURL: String){
        if let userID = currentUser?.uid{
            db.collection("users").whereField("uid", isEqualTo: userID).getDocuments() { (querySnapshot, err) in
                if err != nil {
                    print("err")
                } else if querySnapshot!.documents.count != 1 {
                    print("doc does not exists")
                } else {
                    let document = querySnapshot!.documents.first
                    document!.reference.updateData([
                        "profileImage": profileURL
                    ])
                    print("successfuly changed profile image")
                }
            }
        }

    }
    
    //updates the attending list of an event
    func updateAttendingList(newAttendingList: String, eventTitle: String){
        db.collection("events").whereField("name", isEqualTo: eventTitle).getDocuments() { (querySnapshot, err) in
            if err != nil {
                print("err")
            } else if querySnapshot!.documents.count != 1 {
                print("doc does not exists")
            } else {
                let document = querySnapshot!.documents.first
                document!.reference.updateData([
                    "attendingList": newAttendingList
                ])
                print("successfuly changed attending lists")
            }
        }
    }
    
}
