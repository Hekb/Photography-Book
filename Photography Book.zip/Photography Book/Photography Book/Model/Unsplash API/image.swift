//
//  Image.swift
//  BarbarHekmatHW7
//
//  Created by Hekmat on 4/7/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import Foundation


struct Image : Decodable{
    let id: String
    let width: Int
    let height: Int
    let color: String
    let likes: Int
    let urls: ImageUrl
}
