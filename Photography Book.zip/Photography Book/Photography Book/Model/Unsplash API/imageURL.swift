//
//  ImageUrl.swift
//  BarbarHekmatHW7
//
//  Created by Hekmat on 4/7/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import Foundation


struct ImageUrl : Decodable{
    let raw: String
    let full: String
    let regular: String
    let small: String
    let thumb: String
}
