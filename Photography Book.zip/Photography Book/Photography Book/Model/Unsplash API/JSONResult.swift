//
//  test.swift
//  Photography Book
//
//  Created by Hekmat on 5/4/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import Foundation


struct JSONResult : Decodable{
    let total: Int
    let total_pages: Int
    let results: [Image]
}
