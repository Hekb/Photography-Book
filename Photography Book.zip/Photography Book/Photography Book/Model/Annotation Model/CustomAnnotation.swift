//
//  CustomAnnotation.swift
//  Photography Book
//
//  Created by Hekmat on 5/4/20.
//  Copyright © 2020 Hekmat Barbar. All rights reserved.
//

import Foundation
import MapKit

class CustomAnnotation: NSObject, MKAnnotation {
    
    var coordinate: CLLocationCoordinate2D
    var host: String
    var date: String
    var profilePic: String
    var e: event
    //custom annontation class
    init(host: String, date: String, profilePic: String, coordinate: CLLocationCoordinate2D, ev: event) {
        self.coordinate = coordinate
        self.host = host
        self.date = date
        self.profilePic = profilePic
        self.e = ev
    }
}
